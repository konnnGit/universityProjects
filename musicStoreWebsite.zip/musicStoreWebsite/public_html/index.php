<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<!-- http://zetcode.com/db/postgresqlphp/read/ -->

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

?>

<body>
<br>
<p > <font size= "10"> Main form</font><br><br>

------------------------------------------------------------
<br><p ><b>Add Artist</b>
        <form action="addArtist.php" method="post">
	
            Artist Name : <input required type="text" name="artist_name" size="50" length="50"><BR>
            Popularity : <input required type="number" name="ar_popularity" min="0" max="100" value="0" size="40" length="40"><BR>
            Description : <input required type="text" name="ar_description" size="100" length="200"  ><BR>
            <input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It">
        </form>   
        <br><p ><b></b>
       <button type="button" onclick="parent.location='addArtistFile.php'" style="height: 50px; width: 240px">
			Add artists from file</button>      
      
        
  <br>------------------------------------------------------------

<br><p><b>Add Tracks</b>
        <form action="addTracks.php" method="post">	
           <!-- Title : <input type="text" name="title" size="40" length="40" value=" "><BR>    -->     
            
            Title : <input required type="text" name="title" size="50" length ="50"><BR>
            Artist : <input required type="text" name="artist" size="40" length="40"><BR>
            Album : <input required type="text" name="album" size="40" length="40"><BR> <!--should change later to "text"-->
		  	Duration : <input required type="time" name="duration"  value="00:00 "><BR>
		 	Popularity : <input required type="number" name="t_popularity" min="0" max="100" value="0" size="40" length="40"><BR>
		 	Description : <input required type="text" name="t_description" size="100" length="200"><BR>
			<input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It"> 
               
                      
        </form>   
        <br><p ><b></b>     <button type="button" onclick="parent.location='addTracksFile.php'" style="height: 50px; width: 240px">
            Add tracks from file</button>                  

<br>------------------------------------------------------------
<br><p><b>Add Record Labels</b>
        <form action="addRecordLabels.php" method="post">	              
            
            Label Name: <input required type="text" name="label_name" size="50" length="50"><BR>
            <!-- Year Founded: <input required type="date" name="year_founded" min="01/01/1900" max = "31/12/2200" value = '00/00/00' size="40" length="40"><BR> -->
            Year Founded: <input required type="number" name="year_founded" min = "1900" max = "2016" value="2016">
            Country: <input required type="text" name="country" size="50" length="50"><BR> 
			<input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It"> 

                
    
                      
        </form>       
       <br><p ><b></b>  <button type="button" onclick="parent.location='addRecordLabelsFile.php'" style="height: 50px; width: 240px">
            Add record labels from file</button>                  

<br>------------------------------------------------------------

<br><p><b>Add Albums</b>
        <form action="addAlbums.php" method="post">	                
            
            Album Title: <input required type="text" name="album_title" size="50" length="50"><BR>
            Artist: <input required type="text" name="artist" size="50" length="250"><BR>
            Album Type: <input required type="text" name="album_type" size="200" length="50"><BR> 
			Release Date: <input required type = "date" value = "0000/00/00" name = "release_date"> <BR> 
			<!--Release Date: <input required type = "text" value = "1996-06-04" name = "release_date"> <BR>-->
			Genre: <input required type="text" name="genre" size="50" length="50"> <BR>
			Record Label: <input required type="text" name="record_label" size="50" length="50"> <BR>
			Album Description: <input required type="text" name="album_description" size="50" length="250"> <BR>


			<input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It"> 
    
                      
        </form>   
        <br><p ><b></b>  <button type="button" onclick="parent.location='addAlbumsFile.php'" style="height: 50px; width: 240px">
            Add albums from file</button> 

<br>--------------------------------------------------------------
<br><p> <b>Queries :</b><br>

<br> <a href="http://hilon.dit.uop.gr/~db1u52/allArtistsQ.php">All artists</a> 
<br> <a href="http://hilon.dit.uop.gr/~db1u52/allTracksQ.php">All tracks</a>
<br> <a href="http://hilon.dit.uop.gr/~db1u52/allAlbumsQ.php">All albums</a>
<br> <a href="http://hilon.dit.uop.gr/~db1u52/allRecordLabelsQ.php">All record labels</a>
 

 <br>------------------------------------------------------------

 <BR> <p>DELETE</p>
<br><p ><b>Delete Artist</b>
        <form action="deleteArtist.php" method="post">
    
            Artist Name : <input required type="text" name="artist_name" size="50" length="50"><BR>
            <input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It">
        </form>   
        <br><p ><b></b>



        <br>------------------------------------------------------------

<br><p><b>Delete Track</b>
        <form action="deleteTrack.php" method="post"> 
           <!-- Title : <input type="text" name="title" size="40" length="40" value=" "><BR>    -->     
            
            Title : <input required type="text" name="title" size="50" length="50"><BR>
            Artist : <input required type="text" name="artist" size="40" length="40"><BR>
            Album : <input required type="text" name="album" size="40" length="40"><BR> <!--should change later to "text"-->
            <input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It"> 
               

</form>
               <br>------------------------------------------------------------
<br><p><b>Delete Record Label</b>
        <form action="deleteRecordLabel.php" method="post">                 
            
            <BR> Label Name: <input required type="text" name="label_name" size="50" length="50"><BR>
            <input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It"> 

 </form>
 <br>------------------------------------------------------------

<br><p><b>Delete Album</b>
        <form action="deleteAlbum.php" method="post">                 
            
            Album TItle: <input required type="text" name="album_title" size="50" length="50"><BR>
           <!-- Artist: <input required type="text" name="artist" size="40" length="40"><BR>
            Album Type: <input required type="text" name="album_type" size="50" length="50"><BR> 
            Release Date: <input required type = "date" min="01/01/1900" max = "31/12/2200" value = '00/00/00' name = "release_date"> <BR> 
            Genre: <input required type="text" name="genre" size="50" length="50"> <BR>
            Record Label: <input required type="text" name="record_label" size="50" length="50"> <BR>
            Album Description: <input required type="text" name="album_description" size="50" length="50"> <BR>

            -->


            <input type="submit" name="submit" value="Submit">
            <input type="reset" name="reset" value="Clear It"> 
    
                      
        </form>  
<br>------------------------------------------------------------

<BR>
<button type="button" onclick="parent.location='queries.php'" style="height: 50px; width: 240px">
            Ερωτήματα </button>
</body>

</html>
