<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
  		  header('Content-type: text/html; charset=UTF-8');
 		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");

        $artist_name = pg_escape_string($_POST['artist_name']);
        
        $queryAlbum = "SELECT album_id from albums WHERE album_title = '$_POST[album]' ";
        $resultAlbum = pg_query($queryAlbum);
        $rowAlbum = pg_fetch_row($resultAlbum);
        $albumId = $rowAlbum[0];

        if ($albumId == NULL){ echo "The album doesn't exists. <BR>"; }

        $query= "SELECT artist_id FROM artists WHERE artist_name = '$_POST[artist]' ";	
		  $result = pg_query($query);
		  $row=pg_fetch_row($result);
		  $artistId= $row[0];  // A new variable to store the id that will be inserted later.

        if ($artistId == NULL) {echo "The artist doesn't exists. <BR>"; }


        $queryDelete = "DELETE FROM tracks WHERE title = '$_POST[title]' AND artist = '$artistId' AND album = 'albumId' ";
        $resultDelete = pg_query($queryDelete);
         /*
		  if ($artistId==NULL) {

		  	echo "Artist doesn't exists. <BR>";
		  } else {
            //$queryDelete = "DELETE FROM artists WHERE artist_name = '$_POST[artist_name]'";
            $queryDelete = "DELETE FROM artists WHERE artist_id = '$artistId'";
            $resultDelete = pg_query($queryDelete);
            echo "Artist deleted. <BR> ";
                      
        	} 

*/
        pg_close();
        ?>
    </body>
</html>

