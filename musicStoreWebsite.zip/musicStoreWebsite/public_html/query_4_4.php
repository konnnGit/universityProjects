<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

         $query= "SELECT DISTINCT genre
         			FROM albums
         			ORDER BY genre ASC;";	
		 $result = pg_query($query);



		 $i = 1;
		 //$j = 1;
		 //$k = 1;
		 while ($rowses = pg_fetch_row($result)){

		 	echo "Είδος Μουσικής: $rowses[0]: $i <BR>";
		 		$queryAlbums = "SELECT album_id, album_title
		 						FROM albums
		 						WHERE genre = '$rowses[0]'
		 						ORDER BY album_title ASC;";


		 		//$queryAlbums = "SELECT album_id, album_title FROM albums;";
		 		$resultAlbums = pg_query($queryAlbums);

		 		$j = 1; //////////////////////////////////
		 		while($rowsAlbums = pg_fetch_row($resultAlbums)){
		 			echo "&nbsp;&nbsp;&nbsp&nbsp;&nbsp; Άλμπουμ: $rowsAlbums[1] :$i.$j<BR>";
		 			
		 			$queryTracks = "SELECT track_id, title
		 							FROM tracks
		 							WHERE album = '$rowsAlbums[0]'
		 							ORDER BY track_id ASC;";
		 					$resultTracks = pg_query($queryTracks);
		 					$k = 1;
		 					while($rowTracks = pg_fetch_row($resultTracks)){
		 						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $rowTracks[1] :$i.$j.$k <BR>";
		 						$k++;
		 					}
		 			$j++;
		 		}
		 	$i++;
		 }


?>
------------------------------------------------------------

</body>

</html>
