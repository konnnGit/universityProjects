<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
  		  header('Content-type: text/html; charset=UTF-8');
 		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");

        $artist_name = pg_escape_string($_POST['artist_name']);
        $ar_popularity = pg_escape_string($_POST['ar_popularity']);
        $ar_description = pg_escape_string($_POST['ar_description']);



        $query= "SELECT artist_id FROM artists WHERE artist_name = '$artist_name' ";	
		  $result = pg_query($query);
		  $row=pg_fetch_row($result);
		  $artistId= $row[0];  // A new variable to store the id that will be inserted later.
		  if ($artistId==NULL) {

		  	$query2 = "INSERT INTO artists(artist_name, ar_popularity, ar_description) VALUES ('" . $artist_name . "', '" . $ar_popularity . "', '" . $ar_description . "')";
		  	$result2 = pg_query($query2);
		  	exit(0);
		  } else {
            $errormessage = pg_last_error();
            echo " artist already exists ";
                      
        	} 















/*
        $question = "SELECT * FROM artists WHERE artist_name = '_POST[artist_name]";
        $ansewr = pg_query($question);
        //$answer = pg_exec($db, $question);
        $numrows = pg_numrows($answer);
        if ($numrows == 0){
            $query = "INSERT INTO artists(artist_name, ar_popularity, ar_description) VALUES ('" . $artist_name . "', '" . $ar_popularity . "', '" . $ar_description . "')";
            $result = pg_query($query);
            if (!$result) {
                $errormessage = pg_last_error();
                echo "Error while inserting the table. " . $errormessage;
                exit();
            }
            printf ("These values were inserted into the database - %s %s %s", $artist_name, $ar_popularity, $ar_description);
        } else {
            printf ("The artist already exists.");
        }
  */      
        pg_close();
        ?>
    </body>
</html>

