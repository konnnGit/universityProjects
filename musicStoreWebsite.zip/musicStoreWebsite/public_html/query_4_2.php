<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

         $query= "SELECT label_id, label_name, country
         			FROM record_labels
         			ORDER BY label_name ASC;";	
		 $result = pg_query($query);



		 $i = 1;
		 while ($rowses = pg_fetch_row($result)){
		 	echo "Δισκογραφική εταιρία: $rowses[1] $i - $rowses[2] <BR>";
		 		$queryAlbums = "SELECT album_title, release_date
		 						FROM albums
		 						WHERE record_label = $rowses[0]
		 						ORDER BY release_date ASC;";
		 		$resultAlbums = pg_query($queryAlbums);

		 		$j = 1; //////////////////////////////////
		 		while($rowsAlbums = pg_fetch_row($resultAlbums)){
		 			echo "&nbsp;&nbsp;&nbsp&nbsp;&nbsp; Άλμπουμ: $rowsAlbums[0] $i.$j - $rowsAlbums[1] <BR>";
		 			$j++;
		 		}
		 	$i++;
		 }


?>
------------------------------------------------------------

</body>

</html>
