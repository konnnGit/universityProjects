<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

         $query= "SELECT artist_id, artist_name
         			FROM artists
         			ORDER BY artist_name ASC;";	
		 $result = pg_query($query);



		 $i = 1;
		 while ($rowses = pg_fetch_row($result)){
		 	echo "Καλλιτέχνης: $rowses[1] $i: <BR>";
		 		$queryAlbums = "SELECT album_id, album_title
		 						FROM albums
		 						WHERE artist = $rowses[0]
		 						ORDER BY album_title ASC;";
		 		$resultAlbums = pg_query($queryAlbums);

		 		$j = 1; //////////////////////////////////
		 		while($rowsAlbums = pg_fetch_row($resultAlbums)){
		 			echo "&nbsp;&nbsp;&nbsp&nbsp;&nbsp; Άλμπουμ: $rowsAlbums[1] $i.$j: <BR>";
		 			$queryTracks = "SELECT track_id, title
		 							FROM tracks
		 							WHERE album = $rowsAlbums[0] AND artist = $rowses[0]
		 							ORDER BY track_id ASC;";
		 					$resultTracks = pg_query($queryTracks);
		 					$k = 1;
		 					while($rowTracks = pg_fetch_row($resultTracks)){
		 						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $rowTracks[1] $i.$j.$k <BR>";
		 						$k++;
		 					}
		 			$j++;
		 		}
		 	$i++;
		 }


?>
------------------------------------------------------------

</body>

</html>
