<html>
    <body>
        
<?php
		$db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
		  ini_set("default_charset", "UTF-8");
    	  header('Content-type: text/html; charset=UTF-8');
  		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");
  		  //include 'addArtistFile.php';
  		  
if ($_FILES["file"]["error"] > 0)
  {
  echo "Error: " . $_FILES["file"]["error"] . "<br>";
  }
//copy data from file by checking for previous existence
//$contents= file_get_contents("artists.txt");
$contents= file_get_contents("tracks.txt");
$lines= explode("\n",$contents);
$linecount=count($lines);

for ($i=1; $i<$linecount-1;$i++){
  $input= explode("|",$lines[$i]);
  $query= "SELECT track_id FROM tracks WHERE title = '$input[0]' ";  
  $result = pg_query($query);
  $row=pg_fetch_row($result);
  $trackId= $row[0];  // A new variable to store the id that will be inserted later.

  if ($trackId>0) {
    $errormessage = pg_last_error();
   // echo "Track ". $input[0] ." already exists.<BR>";  
	     
  } 
  else {
  		$queryArtist = "SELECT artist_id FROM artists WHERE artist_name = '$input[2]'";
            $resultArtist = pg_query($queryArtist);
            $rowArtist = pg_fetch_row($resultArtist);
            $artistId = $rowArtist[0];

            $queryAlbums = "SELECT album_id FROM albums WHERE album_title = '$input[1]'";
            $resultAlbums = pg_query($queryAlbums);
            $rowAlbums = pg_fetch_row($resultAlbums);
            $albumId = $rowAlbums[0];


                if($albumId != NULL){
                	if($artistId != NULL) {



                    //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('$_POST[album_title]', '$_POST[artist]', '$_POST[album_type]', '$_POST[release_date]', '$_POST[genre]', '$_POST[record_label]', '$_POST[album_description]')";
                    //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('album_title', 'artist', 'album_type', to_date('1966-11-23', 'YYYY-MM-DD'), 'genre', 'record_label', 'album_description')";
                    //$query2 = "INSERT INTO albums(release_date) VALUES ('$_POST[release_date]')";
                    //$query2 = "INSERT INTO tracks(title, artist, album, duration, t_popularity, t_description) VALUES ('$title, '$artistId', '$albumId', $_POST[duration]', '$_POST[t_popularity]', '$_POST[t_description]')";
                    $query2 = "INSERT INTO tracks(title, artist, album, duration, t_popularity, t_description) VALUES ('$input[0]', '$artistId',  '$albumId','$input[3]', '$input[4]', '$input[5]')";

                    $result2 = pg_query($query2);
                    
                    echo "Track  '" .$input[0] . "' inserted successfully.<BR>";
                    
                    
                   } 
                   else{
                    echo "Artist " . $input[0] . " doesn't exists, adding it ..... <BR>";
                    $queryAddNonExistArtist = "INSERT INTO artists (artist_name) VALUES ('$input[1]')";
                    $resultqueryAddNonExistArtist = pg_query($queryAddNonExistArtist);
                    if($resultqueryAddNonExistArtist) {
                    
                    		echo "Done..<BR>";
                }
                else {echo "Error while adding..<BR>";
                }

            } 
                    
                } 
                
                
                else{
                    echo "Album label " . $input[1] . " doesn't exists, adding it ..... <BR>";
                    $queryAddNonExistLabel = "INSERT INTO albums (album_title) VALUES ('$input[2]')";
                    $resultqueryAddNonExistLabel = pg_query($queryAddNonExistLabel);
                    if($resultqueryAddNonExistLabel) {
                    	echo "<BR>";
                    		echo "Done..<BR>";
                }
                else {echo "Error while adding..<BR>";
                }

            } 
        
    

}
}

pg_close($db);


?>

    </body>
</html>