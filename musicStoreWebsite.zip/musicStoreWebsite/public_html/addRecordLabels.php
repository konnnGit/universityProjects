<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
  		  header('Content-type: text/html; charset=UTF-8');
 		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");

        $label_name = pg_escape_string($_POST['label_name']);
        $year_founded = pg_escape_string($_POST['year_founded']);
        $country = pg_escape_string($_POST['country']);



        $query= "SELECT label_id FROM record_labels WHERE label_name = '$label_name' ";	
		  $result = pg_query($query);
		  $row=pg_fetch_row($result);
		  $labelId= $row[0];  // A new variable to store the id that will be inserted later.
		  if ($labelId==NULL) {

		  	///$query2 = "INSERT INTO record_labels(label_name, year_founded, country) VALUES ('" . $label_name . "', '" . $year_founded . "', '" . $country . "')";
            $query2 = "INSERT INTO record_labels(label_name, year_founded, country) VALUES ('$_POST[label_name]', '$_POST[year_founded]', '$_POST[country]')";
		  	$result2 = pg_query($query2);
		  	echo "Record label inserted succesfully.";
		  	exit(0);
		  } else {
            $errormessage = pg_last_error();
            echo " Record label already exists ";
                      
        	} 
        pg_close();
        ?>
    </body>
</html>

