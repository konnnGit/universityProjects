<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

         $query= "SELECT DISTINCT artist
         			FROM tracks 
         			WHERE duration > '$_POST[d]' ;";	
		 $result = pg_query($query);



		 echo "Artist ID: Artist name <BR>";
		 while ($rowses = pg_fetch_row($result)){
		 	$query2 = "SELECT artist_name FROM artists WHERE artist_id = $rowses[0]";
		 	$result2 = pg_query($query2);
		 	$row2 = pg_fetch_row($result2);

		 	echo "$rowses[0]: $row2[0]<BR>";
		 	
		 }



?>

------------------------------------------------------------

    


</body>

</html>
