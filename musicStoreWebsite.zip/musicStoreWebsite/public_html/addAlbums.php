<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
  		  header('Content-type: text/html; charset=UTF-8');
 		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");

       

        $album_title = pg_escape_string($_POST['album_title']);
        $artist= pg_escape_string($_POST['artist']);
        $album_type = pg_escape_string($_POST['album_type']);
        $record_label = pg_escape_string($_POST['record_label']);
			
		


         $query= "SELECT album_id FROM albums WHERE album_title = '$album_title' ";	

		  $result = pg_query($query);
		  $row= pg_fetch_row($result);
		  $albumId= $row[0];  // A new variable to store the id that will be inserted later.
		  if ($albumId >= 1) {
            //$errormessage = pg_last_error();
            echo " Album already exists " . $errormessage;
            exit(0);

		  	
		  } else {
		  	echo " Album editing.. " . $album_title . "<BR>";
		  	

            $queryArtist = "SELECT artist_id FROM artists WHERE artist_name = '$artist'";
            $resultArtist = pg_query($queryArtist);
            $rowArtist = pg_fetch_row($resultArtist);
            $artistId = $rowArtist[0];
            echo "artistId=".$artistId."<BR>";

            $queryRecordLabel = "SELECT label_id FROM record_labels WHERE label_name = '$record_label'";
            $resultRecordLabel = pg_query($queryRecordLabel);
            $rowRecordLabel = pg_fetch_row($resultRecordLabel);
            $labelId = $rowRecordLabel[0];
            echo"labelId=". $labelId."<BR>";



            if($artistId != NULL  && $labelId != NULL){

                

               



                    //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('$_POST[album_title]', '$_POST[artist]', '$_POST[album_type]', '$_POST[release_date]', '$_POST[genre]', '$_POST[record_label]', '$_POST[album_description]')";
                    //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('album_title', 'artist', 'album_type', to_date('1966-11-23', 'YYYY-MM-DD'), 'genre', 'record_label', 'album_description')";
                    //$query2 = "INSERT INTO albums(release_date) VALUES ('$_POST[release_date]')";
                    $query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('$_POST[album_title]', ' $artistId ', '$_POST[album_type]', '$_POST[release_date]', '$_POST[genre]', '$labelId', '$_POST[album_description]')";
                    $result2 = pg_query($query2);
                    if(!$result2) {
                    	$errormessage2 = pg_last_error();
                    echo "Album did not inserted successfully." . $errormessage2;
                 }
                
                
                

            } 
            else{
                    echo "Record label doesn't exists or artist doesn't exist. <BR>";
                }
            
                      
        	} 
        pg_close($db);
        ?>
    </body>
</html>

