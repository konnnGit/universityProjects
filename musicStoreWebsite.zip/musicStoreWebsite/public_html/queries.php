<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<!-- http://zetcode.com/db/postgresqlphp/read/ -->

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

?>

<body>
<br>
<p > <font size= "10"> Main form</font><br><br>
------------------------------------------------------------
<br><b>4.1)  Παρουσίαση καλλιτεχνών, άλμπουμ και τραγουδιών.</b>
        <form action="query_4_1.php" method="post">
    
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form> 
------------------------------------------------------------
<br><b>4.2)  Παρουσίαση δισκογραφικών εταιριών και άλμπουμ.</b>
        <form action="query_4_2.php" method="post">
    
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form> 
------------------------------------------------------------
<br><b>4.3)  Παρουσίαση καλλιτεχνών και τραγουδιών.</b>
        <form action="query_4_3.php" method="post">
    
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form> 

------------------------------------------------------------
<br><b>4.4)  Παρουσίαση ειδών μουσικής, άλμπουμ και τραγουδιών.σ</b>
        <form action="query_4_4.php" method="post">
    
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form> 

------------------------------------------------------------
<br><b>5.1) Όλα τα τραγούδια με βαθμό μεγαλύτερο από: </b>
        <form action="query_5_1.php" method="post">
	B_T: <input required type="number" name="b_t" min = "0" max = "100" value="0">
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form>   
------------------------------------------------------------
  <br><b>5.2) Όλοι οι καλλιτέχνες με τραγούδια διάρκεις μεγαλύτερης από: </b>
        <form action="query_5_2.php" method="post">
    Δ: <input required type="time" name="d"  value="00:00"><BR>
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form>   
------------------------------------------------------------

 <br><b>5.3) Όλα τα τραγούδια μουσικού είδους: </b>
        <form action="query_5_3.php" method="post">
         Μ: <input required type="text" name="genre" size="50" length="50"> <BR>
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form>    
  ------------------------------------------------------------
  <br><b>5.6) Όλοι οι καλλιτέχνες που κυκλοφόρησαν άλμπουμ πριν από το: </b>
        <form action="query_5_6.php" method="post">
    Ε: <input required type="number" name="e" min = "1900" max = "2016" value="2016">
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form>   
 ------------------------------------------------------------
        <br><b>5.8) Βρείτε τα τραγούδια των οποίων η δισκογραφική εταιρία ιδρύθηκε μετά το έτος Ε: </b>
        <form action="query_5_8.php" method="post">

      
         Ε: <input required type="number" name="e" min = "1900" max = "2016" value="2016">
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form>   
------------------------------------------------------------
 <br><b>5.16) Τα διασημότερα τραγούδια της δησκογραφικής: </b>
        <form action="query_5_6.php" method="post">
    Ρ: <input required type="text" name="p" size="50" length="50"> <BR>
            
            <BR>
            <input type="submit" name="submit" value="Εκτέλεση">
        
        </form>   
------------------------------------------------------------


</body>

</html>
