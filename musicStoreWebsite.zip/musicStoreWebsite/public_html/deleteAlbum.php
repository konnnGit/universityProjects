<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
  		  header('Content-type: text/html; charset=UTF-8');
 		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");
        

        $query= "SELECT album_id FROM albums WHERE album_title = '$_POST[album_title]' ";	
		  $result = pg_query($query);
		  $row=pg_fetch_row($result);
		  $albumId= $row[0];  // A new variable to store the id that will be inserted later.
		  if ($albumId==NULL) {

		  	echo "Album doesn't exists. <BR>";
		  } else {
            //$queryDelete = "DELETE FROM artists WHERE artist_name = '$_POST[artist_name]'";
            $queryDelete = "DELETE FROM albums WHERE album_id = '$albumId'";
            $resultDelete = pg_query($queryDelete);
            echo "Album deleted. <BR> ";
                      
        	} 

        pg_close();
        ?>
    </body>
</html>

