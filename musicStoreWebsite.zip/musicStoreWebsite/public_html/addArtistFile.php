<html>
    <body>
        
<?php
		$db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
		  ini_set("default_charset", "UTF-8");
    	  header('Content-type: text/html; charset=UTF-8');
  		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");
  		  
if ($_FILES["file"]["error"] > 0)
  {
  echo "Error: " . $_FILES["file"]["error"] . "<BR>";
  }

//$file=$_FILES["artists.txt"]["tmp_name"];
//$handle = fopen($file, "r");
//$contents = fread($handle, filesize($file));
$contents= file_get_contents("artists.txt");
//$contents=pg_escape_string($contents);
$lines= explode("\n",$contents);
$linecount=count($lines);
//echo $linecount;


for ($i=1; $i<$linecount-1;$i++){
  $input= explode("|",$lines[$i]);
  
  $query= "SELECT artist_id FROM artists WHERE artist_name = '$input[0]' ";  
  $result = pg_query($query);
  $row=pg_fetch_row($result);
  $artistId= $row[0];  // A new variable to store the id that will be inserted later.

  if ($artistId>0) {
    $errormessage = pg_last_error();
    echo "Artist ". $input[0] ." already exists.<BR>";  
    
  } else {
    $query2 = "INSERT INTO artists(artist_name, ar_popularity, ar_description) VALUES ('$input[0]','$input[1]','$input[2]')";
    $result2 = pg_query($query2);
    echo "Artist " .$input[0]. " inserted successfully.<BR>";           
    } 








/*
if ($artistId==NULL) {
    $query2 = "INSERT INTO artists(artist_name, ar_popularity, ar_description) VALUES ('$input[0]','$input[1]','$input[2]')";
    $result2 = pg_query($query2);
    echo "Artist " .$input[0]. " inserted succesfully.<BR>";
    
  } else {
    $errormessage = pg_last_error();
    echo "Artist ". $input[0] ." already exists.<BR>";                 
    } 

*/
}


/*
for ($i=1; $i<$linecount;$i++){
$input= explode("|",$lines[$i]);

$query3 =  "INSERT INTO artists(artist_name, ar_popularity, ar_description) VALUES ('$input[0]','$input[1]','$input[2]')";
$result = pg_query($query3);


}
if($result){
	echo "Success while importing";
}
else {
	echo "No success while importing";
	
	}

  */



pg_close($db);
//fclose($handle);


?>

<br> <a href="http://hilon.dit.uop.gr/~db1u52/allArtistsQ.php">See all artists</a><br>
    </body>
</html>

