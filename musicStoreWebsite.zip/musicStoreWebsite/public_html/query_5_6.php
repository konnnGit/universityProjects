<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

        //$querya = "SELECT extract (year from date(release_date)"
         $query= "SELECT album_id
        			FROM albums
        			WHERE extract(year from date (release_date)) < $_POST[e];";
//

      //  			$query= "SELECT album_id
      //  			FROM albums
      //  			WHERE release_date < $_POST[e];";	
		 $result = pg_query($query);

		 $i = 1;
		 while ($rowses = pg_fetch_row($result)){
		 	//echo "$rowses[0] $i <BR>";
		 		$queryAlbums = "SELECT  artist
		 						FROM tracks
		 						WHERE album = '$rowses[0]';";
		 		$resultAlbums = pg_query($queryAlbums);

		 		$j = 1; //////////////////////////////////
		 		//$rowsAlbums = pg_fetch_row($resultAlbums));
		 		//while($rowsAlbums = pg_fetch_row($resultAlbums)){
		 			//echo "&nbsp;&nbsp;&nbsp&nbsp;&nbsp; $rowsAlbums[0] $i.$j<BR>";
		 			$queryTracks = "SELECT DISTINCT artist_name
		 							FROM artists
		 							WHERE artist_id = '$rowsAlbums[0]'
		 							ORDER BY artist_name ASC;";
		 					$resultTracks = pg_query($queryTracks);
		 					$k = 1;
		 					//$rowTracks = pg_fetch_row($resultTracks);
		 					
		 					//echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $rowTracks[0] <BR>";
		 					while($rowTracks = pg_fetch_row($resultTracks)){
		 						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $rowTracks[0] <BR>";
		 						$k++;
		 					}
		 			$j++;
		 		//}


		 	$i++;
		 }

?>
------------------------------------------------------------

</body>

</html>
