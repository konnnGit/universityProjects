<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

         $query= "SELECT artist_id, artist_name
         			FROM artists
         			ORDER BY artist_name ASC;";	
		 $result = pg_query($query);



		 $i = 1;
		 while ($rowses = pg_fetch_row($result)){
		 	echo "Καλλιτέχνης: $rowses[1] $i <BR>";
		 		$queryTracks = "SELECT title, t_popularity
		 						FROM tracks
		 						WHERE artist = $rowses[0]
		 						ORDER BY t_popularity DESC;";
		 		$resultTracks = pg_query($queryTracks);

		 		$j = 1; //////////////////////////////////
		 		while($rowsTracks = pg_fetch_row($resultTracks)){
		 			echo "&nbsp;&nbsp;&nbsp&nbsp;&nbsp; $rowsTracks[0] $i.$j - $rowsTracks[1] <BR>";
		 			$j++;
		 		}
		 	$i++;
		 }


?>
------------------------------------------------------------

</body>

</html>
