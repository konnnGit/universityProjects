<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
        header('Content-type: text/html; charset=UTF-8');
        mb_internal_encoding('UTF-8');
        mb_http_input("utf-8");

       

        $title = pg_escape_string($_POST['title']);
        $artist = pg_escape_string($_POST['artist']);
        $album = pg_escape_string($_POST['album']);
        $d= pg_escape_string($_POST['duration']);
        $p= pg_escape_string$_POST['t_popularity'];
        $de= pg_escape_string($_POST['t_description']);
        
        //$title = pg_escape_string($_POST['title']);

        $query= "SELECT track_id FROM tracks WHERE title = '$title' "; 
       // $morequery= "SELECT album_id FROM albums WHERE album_title = '$album' ";         

      $result = pg_query($query);
     // $moreresult = pg_query($morequery);
      $row= pg_fetch_row($result);
     // $morerow= pg_fetch_row($moreresult);
      $trackId= $row[0]; 
     // $morealbumId= $morerow[0];
      if ($trackId > 0  ) { //cross-check for double tuples
           // $errormessage = pg_last_error();
           
            echo " Track of that album already exists <BR>";
         

        
      } else {

            $queryArtist = "SELECT artist_id FROM artists WHERE artist_name = '$artist'";
            $resultArtist = pg_query($queryArtist);
            $rowArtist = pg_fetch_row($resultArtist);
            $artistId = $rowArtist[0];

            $queryAlbums = "SELECT album_id FROM albums WHERE album_title = '$album'";
            $resultAlbums = pg_query($queryAlbums);
            $rowAlbums = pg_fetch_row($resultAlbums);
            $albumId = $rowAlbums[0];



            if($artistId != NULL){

                

                if($albumId != NULL){



                    //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('$_POST[album_title]', '$_POST[artist]', '$_POST[album_type]', '$_POST[release_date]', '$_POST[genre]', '$_POST[record_label]', '$_POST[album_description]')";
                    //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('album_title', 'artist', 'album_type', to_date('1966-11-23', 'YYYY-MM-DD'), 'genre', 'record_label', 'album_description')";
                    //$query2 = "INSERT INTO albums(release_date) VALUES ('$_POST[release_date]')";
                    //$query2 = "INSERT INTO tracks(title, artist, album, duration, t_popularity, t_description) VALUES ('$title, '$artistId', '$albumId', $_POST[duration]', '$_POST[t_popularity]', '$_POST[t_description]')";
                    $query2 = "INSERT INTO tracks(title, artist, album, duration, t_popularity, t_description) VALUES (' $title ', ' $artistId ', ' $albumId ', ' $d ', ' $p ', ' $de ')";

                    $result2 = pg_query($query2);
                    if($result2) {
                    	echo "Track inserted successfully.";
                    }
                    
                }
                 else{
                    echo "Album label '" . $album . "' doesn't exists. <BR>";
                    
                    }
                    	
                    
                }

            } else{
                echo "Artist '" .$artist. "' doesn't exist. <BR>";

            }
                      
           
        pg_close($db);
        ?>
    </body>
</html>

