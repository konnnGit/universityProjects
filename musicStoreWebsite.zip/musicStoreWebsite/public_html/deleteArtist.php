<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
  		  header('Content-type: text/html; charset=UTF-8');
 		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");

        $artist_name = pg_escape_string($_POST['artist_name']);
        

        $query= "SELECT artist_id FROM artists WHERE artist_name = '$artist_name' ";	
		  $result = pg_query($query);
		  $row=pg_fetch_row($result);
		  $artistId= $row[0];  // A new variable to store the id that will be inserted later.
		  if ($artistId==NULL) {

		  	echo "Artist doesn't exists. <BR>";
		  } else {
            //$queryDelete = "DELETE FROM artists WHERE artist_name = '$_POST[artist_name]'";
            $queryDelete = "DELETE FROM artists WHERE artist_id = '$artistId'";
            $resultDelete = pg_query($queryDelete);
            echo "Artist deleted. <BR> ";
                      
        	} 

        pg_close();
        ?>
    </body>
</html>

