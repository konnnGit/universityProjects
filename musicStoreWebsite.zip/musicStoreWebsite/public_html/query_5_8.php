<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

         $query= "SELECT label_id 
         			FROM record_labels
         			WHERE year_founded < $_POST[e] ";	
		 $result = pg_query($query);



		 echo "Popularity : Title <BR>";
		 while ($rowses = pg_fetch_row($result)){
		 	$query2 = "SELECT album_id
		 				FROM albums
		 				WHERE record_label = $rowses[0]";
		 	$result2 = pg_query($query2);

		 	while($rows2 = pg_fetch_row($result2)){
		 		$query3 = "SELECT title
		 					FROM tracks
		 					WHERE album = $rows2[0]";
		 		$result3 = pg_fetch_row($result3);
		 		while ($rows3 = pg_fetch_row($result3)) {
		 			echo $rows3[0] ;
		 			
		 		}
		 	}
		 	
		 }



?>

------------------------------------------------------------

    


</body>

</html>
