<html>
    <body>
        
<?php
		$db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
		  ini_set("default_charset", "UTF-8");
    	  header('Content-type: text/html; charset=UTF-8');
  		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");
  		  //include 'addArtistFile.php';
  		  
if ($_FILES["file"]["error"] > 0)
  {
  echo "Error: " . $_FILES["file"]["error"] . "<br>";
  }
//copy data from file by checking for previous existence
//$contents= file_get_contents("artists.txt");
$contents= file_get_contents("albums.txt");
$lines= explode("\n",$contents);
$linecount=count($lines);

for ($i=1; $i<$linecount-1;$i++){
  
  $input= explode("|",$lines[$i]);
  /*
  $query= "SELECT album_id FROM albums WHERE album_title = '$input[0]' ";  
  $result = pg_query($query);
  $row=pg_fetch_row($result);
  $albumId= $row[0];  // A new variable to store the id that will be inserted later.

  if ($albumId>0) {
    $errormessage = pg_last_error();
    echo "Album ". $input[0] ." already exists.<BR>";  
    
  } else {---------*/
  		      $queryArtist = "SELECT artist_id FROM artists WHERE artist_name = '$input[1]'";
            $resultArtist = pg_query($queryArtist);
            $rowArtist = pg_fetch_row($resultArtist);
            $artistId = $rowArtist[0];

            $queryAlbums = "SELECT album_id FROM albums WHERE album_title = '$input[2]'";
            $resultAlbums = pg_query($queryAlbums);
            $rowAlbums = pg_fetch_row($resultAlbums);
            $albumId = $rowAlbums[0];

            $queryRecordLabels = "SELECT label_id FROM record_labels WHERE label_name = '$input[5]'";
            $resultRecordLabels = pg_query($queryRecordLabels);
            $rowRecordLabels = pg_fetch_row($resultRecordLabels);
            $recordLabelsId = $rowRecordLabels[0];

				if( $albumId >0){
                    echo "Record label doesn't exists or artist doesn't exist. <BR>";
                    
                }

            else {

              if ($recordLabelsId != NULL && $artistId != NULL ){

                

                  //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('$_POST[album_title]', '$_POST[artist]', '$_POST[album_type]', '$_POST[release_date]', '$_POST[genre]', '$_POST[record_label]', '$_POST[album_description]')";
                  //$query2 = "INSERT INTO albums(album_title, artist, album_type, release_date, genre, record_label, album_description) VALUES ('album_title', 'artist', 'album_type', to_date('1966-11-23', 'YYYY-MM-DD'), 'genre', 'record_label', 'album_description')";
                  //$query2 = "INSERT INTO albums(release_date) VALUES ('$_POST[release_date]')";
                  //$query2 = "INSERT INTO tracks(title, artist, album, duration, t_popularity, t_description) VALUES ('$title, '$artistId', '$albumId', $_POST[duration]', '$_POST[t_popularity]', '$_POST[t_description]')";
                
                //  $queryinsert = "INSERT INTO albums (album_title, artist, album_type, release_date, genre, record_label, album_description ) VALUES ('$input[0]','$artistId','$input[2]', '$input[3]', '$input[4]', '$recordLabelsId', '$input[6]')";
                //  $result2 = pg_query($query2);
                  //echo "Album inserted successfully. <BR>";
                    
                
              

             //   $queryInsertRecordLabel = "INSERT INTO record_labels (label_name) VALUES ('$input[5]')";
             //   $result3 = pg_query($queryInsertRecordLabel);
             //  $queryRecordLabels2 = "SELECT label_id FROM record_labels WHERE label_name = '$input[5]'";
            //    $resultRecordLabels2 = pg_query($queryRecordLabels2);
             //   $rowRecordLabels2 = pg_fetch_row($resultRecordLabels2);
             //   $recordLabelsId2 = $rowRecordLabels2[0];

                $queryinsert2 = "INSERT INTO albums (album_title, artist, album_type, release_date, genre, record_label, album_description ) VALUES ('$input[0]','$artistId','$input[2]', '$input[3]', '$input[4]', '$recordLabelsId', '$input[6]')";
               // echo "Record or album Label doesn't exists  . <BR>";
               $resultQ2= pg_query($queryinsert2);
            
               if($resultQ2) {
                echo "Album " .$input[0]. " added. <BR>";
                }
              

            } 
            
        
    }
 }
 pg_close($db);
//fclose($handle);


?>

    </body>
</html>
