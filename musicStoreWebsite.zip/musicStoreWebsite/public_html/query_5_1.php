<html>
<head>
        <title>Music Industry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body bgcolor="white">
<?php
$host = "localhost";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

         $query= "SELECT title, t_popularity FROM tracks WHERE t_popularity > $_POST[b_t] ";	
		 $result = pg_query($query);



		 echo "Popularity : Title <BR>";
		 while ($rowses = pg_fetch_row($result)){
		 	echo " $rowses[1]: 		$rowses[0]<BR>";
		 	
		 }



?>

------------------------------------------------------------

    


</body>

</html>
