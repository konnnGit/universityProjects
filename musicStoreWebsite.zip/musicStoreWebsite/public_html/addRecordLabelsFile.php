<html>
    <body>
        
<?php
		$db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
		  ini_set("default_charset", "UTF-8");
    	  header('Content-type: text/html; charset=UTF-8');
  		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");
  		  
  if ($_FILES["file"]["error"] > 0){
    echo "Error: " . $_FILES["file"]["error"] . "<br>";
  }


$contents= file_get_contents("record_labels.txt");
$lines= explode("\n",$contents);
$linecount=count($lines);
//echo $linecount;


for ($i=1; $i < $linecount; $i++){
  $input= explode("|",$lines[$i]);
  
  $query= "SELECT label_id FROM record_labels WHERE label_name = '$input[0]' ";  
  $result = pg_query($query);
  $row=pg_fetch_row($result);
  $labelId= $row[0];  // A new variable to store the id that will be inserted later.

  if ($labelId>0) {
    $errormessage = pg_last_error();
    echo "Label ". $input[0] ." already exists.<BR>";  
    
  } else {
    $query2 = "INSERT INTO record_labels(label_name, year_founded, country) VALUES ('$input[0]','$input[1]','$input[2]')";
    $result2 = pg_query($query2);
    if($result2) {
    echo "Label " .$input[0]. " inserted successfully.<BR>";  
     } 
     else {echo "Label " .$input[0]. " did not  inserted successfully.<BR>"; 
     }        
    } 

}

pg_close($db);
//fclose($handle);


?>


    </body>
</html>

