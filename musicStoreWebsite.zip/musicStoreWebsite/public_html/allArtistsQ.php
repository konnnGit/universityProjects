<html>
    <body>
        <?php
        $db = pg_connect('host=localhost dbname=db1u52 user=db1u52 password=zdoPC1x5');
        ini_set("default_charset", "UTF-8");
    	  header('Content-type: text/html; charset=UTF-8');
  		  mb_internal_encoding('UTF-8');
  		  mb_http_input("utf-8");
        

       // $artist_name = pg_escape_string($_POST['artist_name']);
      // $ar_popularity = pg_escape_string($_POST['ar_popularity']);
      //  $ar_description = pg_escape_string($_POST['ar_description']);

        $query = "SELECT * FROM artists";
        $result = pg_query($query);
	$i = 0;
echo '<html><body><table><tr>';
while ($i < pg_num_fields($result))
{
	$fieldName = pg_field_name($result, $i);
	echo '<td>' . $fieldName . '</td>';
	$i = $i + 1;
}
echo '</tr>';
$i = 0;

while ($row = pg_fetch_row($result)) 
{
	echo '<tr>';
	$count = count($row);
	$y = 0;
	while ($y < $count)
	{
		$c_row = current($row);
		echo '<td>' . $c_row . '</td>';
		next($row);
		$y = $y + 1;
	}
	echo '</tr>';
	$i = $i + 1;
}
pg_free_result($result);

echo '</table></body></html>';
        if (!$result) {
            $errormessage = pg_last_error();
            echo "Error with query: " . $errormessage;
            exit();
        }
    
        pg_close();
        ?>
    </body>
</html>
