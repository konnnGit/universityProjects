<html>
<head>
        <title>Test</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<!-- http://zetcode.com/db/postgresqlphp/read/ -->

<body bgcolor="white">
<?php
$host = "hilon.dit.uop.gr";
$user = "db1u52";
// Εδώ βάλετε την ομάδα σας --> 
$pass = "zdoPC1x5";
// Εδώ βάλετε τον κωδικό σας -->
$db = $user;

$con = pg_connect("host=$host dbname=$db user=$user password=$pass")
        or die ("Could not connect to server\n");

?>

</body>

</html>
